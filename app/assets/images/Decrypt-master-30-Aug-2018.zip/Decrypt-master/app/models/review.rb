class Review < ApplicationRecord
  belongs_to :exchange
end
