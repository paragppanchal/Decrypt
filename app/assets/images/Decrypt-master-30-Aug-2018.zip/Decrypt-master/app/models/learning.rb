class Learning < ApplicationRecord
end
