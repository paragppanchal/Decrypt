class ApplicationMailer < ActionMailer::Base
  default from: 'zoleaspirez@gmail.com'
  layout 'mailer'
end
