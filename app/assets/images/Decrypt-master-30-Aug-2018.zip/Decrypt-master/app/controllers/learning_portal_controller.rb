class LearningPortalController < ApplicationController
  # def show
  #   @learning = Learning.find(params[:id])
  # end


end
