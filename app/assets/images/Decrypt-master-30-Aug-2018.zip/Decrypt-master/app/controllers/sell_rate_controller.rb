class SellRateController < ApplicationController
end
