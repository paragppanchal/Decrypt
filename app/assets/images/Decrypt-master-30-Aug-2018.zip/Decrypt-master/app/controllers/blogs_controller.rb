class BlogsController < ApplicationController
end
