require 'test_helper'

class LearningTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
