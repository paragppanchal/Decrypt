require 'test_helper'

class ExchangesCoinTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
